'''

'''


def hello_user(name:str):
    print(f"hello {name}")
